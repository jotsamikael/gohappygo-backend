import { Controller } from '@nestjs/common';

@Controller('request-status-history')
export class RequestStatusHistoryController {}
