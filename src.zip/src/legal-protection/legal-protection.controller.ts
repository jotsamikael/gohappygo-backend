import { Controller } from '@nestjs/common';

@Controller('legal-protection')
export class LegalProtectionController {}
