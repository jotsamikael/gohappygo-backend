export class CreateFlightDto {}
