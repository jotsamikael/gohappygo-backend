import { Controller } from '@nestjs/common';

@Controller('insurance')
export class InsuranceController {}
