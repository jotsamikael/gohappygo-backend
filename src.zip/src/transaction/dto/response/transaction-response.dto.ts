export class TransactionResponseDto{
    
}