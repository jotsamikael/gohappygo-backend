export default ()=>({
    appName: process.env.APP_NAME || 'GoHappyGo-API'
})