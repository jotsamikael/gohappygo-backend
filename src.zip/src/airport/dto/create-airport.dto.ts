export class CreateAirportDto {}
