import { Controller } from '@nestjs/common';

@Controller('uploaded-file')
export class UploadedFileController {}
