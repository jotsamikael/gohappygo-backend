import { Controller } from '@nestjs/common';

@Controller('user-verification-audit')
export class UserVerificationAuditController {}
