export enum PackageKind {
    FRAGILE = 'FRAGILE',
    URGENT = 'URGENT',
    STANDARD = 'STANDARD',
    MORE_THAN_3000 = 'MORE_THAN_3000'
}