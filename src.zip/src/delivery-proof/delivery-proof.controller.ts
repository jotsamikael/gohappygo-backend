import { Controller } from '@nestjs/common';

@Controller('delivery-proof')
export class DeliveryProofController {}
