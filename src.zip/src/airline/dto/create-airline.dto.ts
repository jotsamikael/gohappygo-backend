export class CreateAirlineDto {}
